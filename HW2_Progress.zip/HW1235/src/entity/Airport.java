package entity;

public class Airport {

	private final int code;
	private String country;
	private String city;
	private int timeZone;

	public Airport(int code, String country, String city, int timeZone) {
		this.code = code;
		this.country = country;
		this.city = city;
		this.timeZone = timeZone;
	}

	public Airport(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(int timeZone) {
		this.timeZone = timeZone;
	}

	@Override
	public String toString() {
		return "Airport [code=" + code + ", country=" + country + ", city=" + city + ", timeZone=" + timeZone + "]";
	}

}
