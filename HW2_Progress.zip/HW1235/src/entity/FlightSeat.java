package entity;

public class FlightSeat {

	private final int seatID;
	private int rowNum;
	private String numberInRow;
	private String seatClass;

	public FlightSeat(int seatID, int rowNum, String numberInRow, String seatClass) {
		this.seatID = seatID;
		this.rowNum = rowNum;
		this.numberInRow = numberInRow;
		this.seatClass = seatClass;
	}

	public int getSeatID() {
		return seatID;
	}

	public int getRowNum() {
		return rowNum;
	}

	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}

	public String getNumberInRow() {
		return numberInRow;
	}

	public void setNumberInRow(String numberInRow) {
		this.numberInRow = numberInRow;
	}

	public String getSeatClass() {
		return seatClass;
	}

	public void setSeatClass(String seatClass) {
		this.seatClass = seatClass;
	}

	@Override
	public String toString() {
		return "FlightSeat [seatID=" + seatID + ", rowNum=" + rowNum + ", numberInRow=" + numberInRow + ", seatClass="
				+ seatClass + "]";
	}

}
