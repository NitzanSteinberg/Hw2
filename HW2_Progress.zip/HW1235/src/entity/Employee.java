package entity;

import java.time.LocalDate;

public class Employee {

	private final int employeeID;
	private String firstName;
	private String lastName;
	private LocalDate startWorkDate;
	private LocalDate finishWorkDate;

	public Employee(int employeeID, String firstName, String lastName, LocalDate startWorkDate,
			LocalDate finishWorkDate) {
		this.employeeID = employeeID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.startWorkDate = startWorkDate;
		this.finishWorkDate = finishWorkDate;
	}

	public int getEmployeeID() {
		return employeeID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public LocalDate getStartWorkDate() {
		return startWorkDate;
	}

	public void setStartWorkDate(LocalDate startWorkDate) {
		this.startWorkDate = startWorkDate;
	}

	public LocalDate getFinishWorkDate() {
		return finishWorkDate;
	}

	public void setFinishWorkDate(LocalDate finishWorkDate) {
		this.finishWorkDate = finishWorkDate;
	}

	@Override
	public String toString() {
		return "Employee [employeeID=" + employeeID + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", startWorkDate=" + startWorkDate + ", finishWorkDate=" + finishWorkDate + "]";
	}

}
