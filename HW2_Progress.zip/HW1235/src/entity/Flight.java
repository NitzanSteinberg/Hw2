package entity;

import java.sql.Timestamp;
import java.util.Date;

public class Flight {

	private final String UniqueSerialNumber;
	private Timestamp DepartureTime;
	private Timestamp LandingTime;
	private int CodeDepartureAirport;
	private int CodeDestinationAirport;
	private String Status;
	private String AirplaneTailNumber;
	private Long MainPilotID;
	private Long SecondaryPilotID;

	public Flight(String uniqueSerialNumber, Timestamp departureTime, Timestamp landingTime, int codeDepartureAirport,
			int codeDestinationAirport, String status, String airplaneTailNumber, Long mainPilotID,
			Long secondaryPilotID) {
		UniqueSerialNumber = uniqueSerialNumber;
		DepartureTime = departureTime;
		LandingTime = landingTime;
		CodeDepartureAirport = codeDepartureAirport;
		CodeDestinationAirport = codeDestinationAirport;
		Status = status;
		AirplaneTailNumber = airplaneTailNumber;
		MainPilotID = mainPilotID;
		SecondaryPilotID = secondaryPilotID;
	}

	public Timestamp getDepartureTime() {
		return DepartureTime;
	}

	public void setDepartureTime(Timestamp departureTime) {
		DepartureTime = departureTime;
	}

	public Timestamp getLandingTime() {
		return LandingTime;
	}

	public void setLandingTime(Timestamp landingTime) {
		LandingTime = landingTime;
	}

	public int getCodeDepartureAirport() {
		return CodeDepartureAirport;
	}

	public void setCodeDepartureAirport(int codeDepartureAirport) {
		CodeDepartureAirport = codeDepartureAirport;
	}

	public int getCodeDestinationAirport() {
		return CodeDestinationAirport;
	}

	public void setCodeDestinationAirport(int codeDestinationAirport) {
		CodeDestinationAirport = codeDestinationAirport;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getAirplaneTailNumber() {
		return AirplaneTailNumber;
	}

	public void setAirplaneTailNumber(String airplaneTailNumber) {
		AirplaneTailNumber = airplaneTailNumber;
	}

	public Long getMainPilotID() {
		return MainPilotID;
	}

	public void setMainPilotID(Long mainPilotID) {
		MainPilotID = mainPilotID;
	}

	public Long getSecondaryPilotID() {
		return SecondaryPilotID;
	}

	public void setSecondaryPilotID(Long secondaryPilotID) {
		SecondaryPilotID = secondaryPilotID;
	}

	public String getUniqueSerialNumber() {
		return UniqueSerialNumber;
	}

	@Override
	public String toString() {
		return "Flight [UniqueSerialNumber=" + UniqueSerialNumber + ", DepartureTime=" + DepartureTime
				+ ", LandingTime=" + LandingTime + ", CodeDepartureAirport=" + CodeDepartureAirport
				+ ", CodeDestinationAirport=" + CodeDestinationAirport + ", Status=" + Status + ", AirplaneTailNumber="
				+ AirplaneTailNumber + ", MainPilotID=" + MainPilotID + ", SecondaryPilotID=" + SecondaryPilotID + "]";
	}

}