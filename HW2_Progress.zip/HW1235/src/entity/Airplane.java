package entity;

public class Airplane {

	private final String TailNumber;
	private int NumOfAirAttendant;

	public Airplane(String tailNumber, int numOfAirAttendant) {
		TailNumber = tailNumber;
		NumOfAirAttendant = numOfAirAttendant;
	}

	public Airplane(String tailNumber) {
		TailNumber = tailNumber;
	}

	public String getTailNumber() {
		return TailNumber;
	}

	public int getNumOfAirAttendant() {
		return NumOfAirAttendant;
	}

	public void setNumOfAirAttendant(int numOfAirAttendant) {
		NumOfAirAttendant = numOfAirAttendant;
	}

	@Override
	public String toString() {
		return "Airplane [TailNumber=" + TailNumber + ", NumOfAirAttendant=" + NumOfAirAttendant + "]";
	}


	

}
