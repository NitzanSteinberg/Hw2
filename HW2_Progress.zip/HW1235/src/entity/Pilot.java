package entity;

import java.time.LocalDate;

public class Pilot extends Employee {

	private final int pilotID;
	private LocalDate dateOfLicense;

	public Pilot(int employeeID, String firstName, String lastName, LocalDate startWorkDate, LocalDate finishWorkDate,
			int pilotID, LocalDate dateOfLicense) {
		super(employeeID, firstName, lastName, startWorkDate, finishWorkDate);
		this.pilotID = pilotID;
		this.dateOfLicense = dateOfLicense;
	}

	public LocalDate getDateOfLicense() {
		return dateOfLicense;
	}

	public void setDateOfLicense(LocalDate dateOfLicense) {
		this.dateOfLicense = dateOfLicense;
	}

	public int getPilotID() {
		return pilotID;
	}

	@Override
	public String toString() {
		return "Pilot [pilotID=" + pilotID + ", dateOfLicense=" + dateOfLicense + "]";
	}

}
