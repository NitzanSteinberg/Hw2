package util;

public enum Role {

	CHECK_TICKETS,
	ALLOCATION_SEATS,
	SENDING_LUGGAGE
}
