package util;

public enum FlightStatus {

	DELAYED,
	ON_TIME,
	CANCELED
}
