package util;

public enum seatClass {

	FIRST_CLASS,
	TOURIST_CLASS,
	BUSINESS_CLASS
}
