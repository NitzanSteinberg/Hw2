package control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.Consts;
import entity.Airplane;
import entity.Airport;
import entity.Flight;

public class FlightController {

	public static FlightController instance;

	public static FlightController getInstance() {
		if (instance == null)
			instance = new FlightController();
		return instance;
	}

	/**
	 * fetches all flights from DB file.
	 * 
	 * @return ArrayList of flights.
	 * @throws Exception
	 */
	public ArrayList<Flight> getFlights() {
		ArrayList<Flight> listOfFlights = new ArrayList<Flight>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_FLIGHTS);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					listOfFlights.add(new Flight(rs.getString(i++), rs.getTimestamp(i++), rs.getTimestamp(i++), rs.getInt(i++),
							rs.getInt(i++), rs.getString(i++), rs.getString(i++), rs.getLong(i++), rs.getLong(i++)));
				}
			} catch (SQLException e) {
				e.printStackTrace();

			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return listOfFlights;
	}

	/**
	 * fetches all planes from DB file.
	 * 
	 * @return ArrayList of planes.
	 */
	public ArrayList<Airplane> getAirplanes() {
		ArrayList<Airplane> planesList = new ArrayList<Airplane>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_AIRPLANE);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					planesList.add(new Airplane(rs.getString(i++), rs.getInt(i++)));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return planesList;
	}

	/**
	 * fetches all airports from DB file.
	 * 
	 * @return ArrayList of airports.
	 */
	public ArrayList<Airport> getAirports() {
		ArrayList<Airport> airportsList = new ArrayList<Airport>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_SEL_AIRPORT);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					airportsList.add(new Airport(rs.getInt(i++), rs.getString(i++), rs.getString(i++), rs.getInt(i++)));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return airportsList;
	}


	/**
	 * Adding a new Flight with the parameters received from the form. return true
	 * if the insertion was successful, else - return false
	 * 
	 * @return
	 */

	public boolean addFlight(Flight flight) {
		try {
			Class.forName(Consts.JDBC_STR);
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_FLIGHT)) {
				int i = 1;
				java.sql.Date departureDateSql = new java.sql.Date(flight.getDepartureTime().getTime());
				java.sql.Date landingDateSql = new java.sql.Date(flight.getLandingTime().getTime());
				String tailNum = flight.getAirplaneTailNumber().toString();
				int codeDestinationAirport = flight.getCodeDestinationAirport();
				int codeDepartureAirport = flight.getCodeDepartureAirport();

				stmt.setDate(i++, departureDateSql); // can't be null
				stmt.setDate(i++, landingDateSql); // can't be null
				stmt.setInt(i++, codeDestinationAirport); // can't be null
				stmt.setInt(i++, codeDepartureAirport); // can't be null
				stmt.setString(i++, tailNum); // can't be null

				if (flight.getMainPilotID() != null)
					stmt.setLong(i++, flight.getMainPilotID());
				else
					stmt.setNull(i++, java.sql.Types.VARCHAR);

				if (flight.getSecondaryPilotID() != null)
					stmt.setLong(i++, flight.getSecondaryPilotID());
				else
					stmt.setNull(i++, java.sql.Types.VARCHAR);

				if (flight.getStatus() != null)
					stmt.setString(i++, flight.getStatus());
				else
					stmt.setNull(i++, java.sql.Types.VARCHAR);

				stmt.executeUpdate();
				return true;

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Adding a new Airplane with the parameters received from the form. return true
	 * if the insertion was successful, else - return false
	 * 
	 * @return
	 */
	public boolean addAirplane(Airplane airplane) {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_AIRPLANE)) {
				int i = 1;
				stmt.setInt(i++, airplane.getNumOfAirAttendant()); // can't be null

				stmt.executeUpdate();
				return true;

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static List<Airplane> getAvailableAirplanes (Date departureDate){
		List<Airplane> listOfAviailablePlanes = new ArrayList<Airplane>();
		try {
			Class.forName(Consts.JDBC_STR);
			try(Connection conn = DriverManager.getConnection(util.Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(util.Consts.SQL_SEL_PLANES_BY_FLIGHT)){
				stmt.setDate(1, departureDate);
				ResultSet rs = stmt.executeQuery();{
					while(rs.next()) {
						int i = 1;
						listOfAviailablePlanes.add(new Airplane(rs.getString(i++)));
					}
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return listOfAviailablePlanes;
	}

	/**
	 * Adding a new Airport with the parameters received from the form. return true
	 * if the insertion was successful, else - return false
	 * 
	 * @return
	 */
	public boolean addAirport(Airport airport) {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_AIRPORT)) {
				int i = 1;
				stmt.setString(i++, airport.getCountry()); // can't be null
				stmt.setString(i++, airport.getCity()); // can't be null
				stmt.setInt(i++, airport.getTimeZone()); // can't be null

				stmt.executeUpdate();
				return true;

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}
	public boolean removeAirplane(long employeeID) {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_DEL_AIRPLANE)) {
				
				stmt.setLong(1, employeeID);
				stmt.executeUpdate();
				return true;
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}

}
