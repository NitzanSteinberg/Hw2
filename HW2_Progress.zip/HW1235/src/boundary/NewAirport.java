package boundary;

import java.util.ArrayList;

import control.FlightController;
import entity.Airport;
import entity.Flight;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;  
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class NewAirport {
	
	@FXML
	private AnchorPane addAirportScene;
	@FXML
	private ListView<Airport> listOfAirports;

	ArrayList<Airport> allAirports = new ArrayList<>();

	@FXML
	public void moveHomeScreen(ActionEvent event) throws Exception
	{
		Parent newRoot = FXMLLoader.load(getClass().getResource("/boundary/HomeScreen.fxml"));
		Stage primaryStage = (Stage) addAirportScene.getScene().getWindow();
		primaryStage.getScene().setRoot(newRoot);
		primaryStage.show();
	}
	public void initialize() throws Exception {
		allAirports = FlightController.getInstance().getAirports();
		listOfAirports.setItems(FXCollections.observableArrayList(allAirports));
	}
}
