package boundary;

import java.util.ArrayList;

import control.FlightController;
import entity.Airplane;
import entity.Airport;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;  
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class NewAirplane {
	
	@FXML
	private AnchorPane addAirplaneScene;
	@FXML
	private ListView<Airplane> listOfAirplanes;

	ArrayList<Airplane> allAirplanes = new ArrayList<>();

	@FXML
	public void moveHomeScreen(ActionEvent event) throws Exception
	{
		Parent newRoot = FXMLLoader.load(getClass().getResource("/boundary/HomeScreen.fxml"));
		Stage primaryStage = (Stage) addAirplaneScene.getScene().getWindow();
		primaryStage.getScene().setRoot(newRoot);
		primaryStage.show();
	}
	public void initialize() throws Exception {
		allAirplanes = FlightController.getInstance().getAirplanes();
		listOfAirplanes.setItems(FXCollections.observableArrayList(allAirplanes));
	}

	
}
