package boundary;

import java.util.ArrayList;

import control.FlightController;
import entity.Flight;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class FlightsList {

	@FXML
	private AnchorPane showFlightsList;

	@FXML
	private ListView<Flight> listOfFlights;

	ArrayList<Flight> allFlights = new ArrayList<>();
	
	

	@FXML
	public void moveHomeScreen(ActionEvent event) throws Exception {
		Parent newRoot = FXMLLoader.load(getClass().getResource("/boundary/HomeScreen.fxml"));
		Stage primaryStage = (Stage) listOfFlights.getScene().getWindow();
		primaryStage.getScene().setRoot(newRoot);
		primaryStage.show();
	}

	public void initialize() throws Exception {
		allFlights = FlightController.getInstance().getFlights();
		listOfFlights.setItems(FXCollections.observableArrayList(allFlights));
	}
}
