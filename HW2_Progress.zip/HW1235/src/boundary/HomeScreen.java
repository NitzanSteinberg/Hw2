package boundary;

import javafx.application.Platform;  
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class HomeScreen {

	@FXML
	private AnchorPane homeScreen;
	
	@FXML
	private Button addFlight;
	
	@FXML
	private Button addAirplane;
	
	@FXML
	private Button addAirport;
	
	@FXML
	private Button report;
	
	@FXML
	private Button flightsList;
	
	//for moving window
	public void movePage(String toMove) throws Exception
	{
		Parent newRoot = FXMLLoader.load(getClass().getResource("/boundary/"+toMove+".fxml"));
		Stage primaryStage = (Stage) homeScreen.getScene().getWindow();
		primaryStage.getScene().setRoot(newRoot);
		primaryStage.show();
	}
	
	@FXML
	public void addFlightMove(MouseEvent event) throws Exception
	{
		movePage("NewFlight");
	}
	
	@FXML
	public void addAirplaneMove(MouseEvent event) throws Exception
	{
		movePage("NewAirplane");
	}
	
	@FXML
	public void addAirportMove(MouseEvent event) throws Exception
	{
		movePage("NewAirport");
	}
	
	@FXML
	public void flightsListMove(MouseEvent event) throws Exception
	{
		movePage("FlightsList");
	}
	
	@FXML
	public void reportMove(MouseEvent event) throws Exception
	{
		movePage("Report");
	}
	
	@FXML
	public void logout(MouseEvent event) throws Exception{
		Platform.exit();
		System.exit(0);
	}
	
	
		
	
}
