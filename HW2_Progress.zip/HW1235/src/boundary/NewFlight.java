package boundary;


import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;    
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.stream.Collectors;

import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Alert;
import control.FlightController;
import entity.Airplane;
import entity.Airport;
import entity.Flight;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class NewFlight {

	@FXML
	private TextField serialNum;
	
	@FXML
	private ComboBox<Airport> departureAirport;
	
	@FXML
	private ComboBox<Airport> destinationAirport;
	
	@FXML
	private DatePicker departureDate;
	
	@FXML
	private DatePicker landingDate;
	
	@FXML
	private ComboBox<Integer> dHour;
	
	@FXML
	private ComboBox<Integer> lHour;

	@FXML
	private ComboBox<Integer> dMinute;
	
	@FXML
	private ComboBox<Integer> lMinute;
	
	@FXML
	private ComboBox<Airplane> airplane;
	
	@FXML
	private AnchorPane addFlightScene;
	
	ArrayList<Airport> allAirports = new ArrayList<>(); 
	ArrayList<Airplane> allAirplanes = new ArrayList<>(); 
	
	ObservableList<Integer> hours = FXCollections.observableArrayList(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24);
	ObservableList<Integer> minutes = FXCollections.observableArrayList(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,
			35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60);
	
	
	@FXML
	public void moveHomeScreen(ActionEvent event) throws Exception
	{
		Parent newRoot = FXMLLoader.load(getClass().getResource("/boundary/HomeScreen.fxml"));
		Stage primaryStage = (Stage) addFlightScene.getScene().getWindow();
		primaryStage.getScene().setRoot(newRoot);
		primaryStage.show();
	}
	@FXML
	public void moveToNewAirplane(ActionEvent event) throws Exception
	{
		Parent newRoot = FXMLLoader.load(getClass().getResource("/boundary/NewAirplane.fxml"));
		Stage primaryStage = (Stage) addFlightScene.getScene().getWindow();
		primaryStage.getScene().setRoot(newRoot);
		primaryStage.show();
	}
	@FXML
	public void moveToNewAirport(ActionEvent event) throws Exception
	{
		Parent newRoot = FXMLLoader.load(getClass().getResource("/boundary/NewAirport.fxml"));
		Stage primaryStage = (Stage) addFlightScene.getScene().getWindow();
		primaryStage.getScene().setRoot(newRoot);
		primaryStage.show();
	}
	
	@FXML
	public void initialize() {
		allAirports = FlightController.getInstance().getAirports();
		departureAirport.setItems(FXCollections.observableArrayList(allAirports));
		destinationAirport.setItems(FXCollections.observableArrayList(allAirports));
		allAirplanes = FlightController.getInstance().getAirplanes();
		airplane.setItems(FXCollections.observableArrayList(allAirplanes));
		dHour.setItems(hours);
		lHour.setItems(hours);
		dMinute.setItems(minutes);
		lMinute.setItems(minutes);

	}
	
	public void btnSaveNewFlight(MouseEvent event) throws Exception {
		Boolean flag =false, added = false;
		Flight flight = null;
		
		Date dp = Date.valueOf(departureDate.getValue());
		Date ld = Date.valueOf(landingDate.getValue());
		
		Timestamp dpTime = new Timestamp(dp.getTime());
		Timestamp ldTime = new Timestamp(ld.getTime());
		
		dpTime.setHours(dHour.getValue());
		dpTime.setMinutes(dMinute.getValue());
		ldTime.setHours(lHour.getValue());
		ldTime.setMinutes(lMinute.getValue());
		
		
		if(serialNum != null && departureDate != null && landingDate != null &&   dpTime!= null &&  ldTime != null &&  
				departureAirport != null &&  destinationAirport != null && airplane != null) {
			flight = new Flight(serialNum.getText(), dpTime, ldTime, departureAirport.getValue().getCode(), destinationAirport.getValue().getCode(),
					airplane.getValue().toString(), null, null, null);
			flag = true;
			java.sql.Date sqlDd = new java.sql.Date(dp.getTime());
			List<Airplane> allPlanes = new ArrayList<Airplane>();
			List<Airplane> invalidPlanes = new ArrayList<Airplane>();
			invalidPlanes.addAll(FlightController.getInstance().getAvailableAirplanes(sqlDd));
			allPlanes.addAll(FlightController.getInstance().getAirplanes());
			if(!invalidPlanes.isEmpty()) {
				for(int i=0; i<allPlanes.size(); i++) {
					for(int j=0; j<invalidPlanes.size(); j++) {
						if(allPlanes.get(i).equals(invalidPlanes.get(j))) {
							allPlanes.remove(invalidPlanes.get(j));
						}
					}
				}
			}
		}
		
		if(serialNum.getText()==null || departureDate.getValue() == null ||  landingDate.getValue() == null || departureAirport.getValue() == null || 
				destinationAirport.getValue() == null || airplane.getValue() == null)
		{
			Alert alert = new Alert(AlertType.ERROR, "Empty Field");
			alert.setHeaderText("YOU NEED TO FILL ALL THE FIELDS");
			alert.setTitle("Failed Creating New Show");
			alert.showAndWait();
		}
		
		if(flag)
		{
			if(added = FlightController.getInstance().addFlight(flight))
			{
			if(added = FlightController.getInstance().addFlight(flight)) {
				Alert alert = new Alert(AlertType.INFORMATION, "Show Created Succesfully");
				alert.setHeaderText("Success");
				alert.setTitle("New Show Added");
				alert.showAndWait();
			}
			else
			{
				Alert alert = new Alert(AlertType.ERROR, "Error adding show");
				alert.setHeaderText("Try Again Later");
				alert.setTitle("Error");
				alert.showAndWait();
			}
		}
	}
	}
}
